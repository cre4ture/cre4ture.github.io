<?php

  $universe = 'uni17.ogame.de';

  $pos_count[0] = 9;
  $pos_count[1] = 499;
  $pos_count[2] = 15;

  $sqlconf['solsys_table'] = 'solsys';
  $sqlconf['solsys_planet_table'] = 'planet';
  
  $sqlconf['report_table'] = 'report';
  $sqlconf['report_group_table']['resources'] = 'resources';
  $sqlconf['report_group_table']['fleets'] = 'fleets';
  $sqlconf['report_group_table']['defence'] = 'defence';
  $sqlconf['report_group_table']['buildings'] = 'buildings';
  $sqlconf['report_group_table']['research'] = 'research';
  
  $sqlconf['mysql_server'] = 'localhost';
  $sqlconf['mysql_username'] = 'cS_engine';
  $sqlconf['mysql_password'] = 'XYx8tht7GjqUSr3G';
  $sqlconf['mysql_db'] = 'cS_engine';
  
?>